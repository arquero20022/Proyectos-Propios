
package common;

import org.json.JSONObject;


public interface IToJsonObject {
    public static final String TypeLabel = "GIT_type";
    JSONObject toJSONObject();
}
