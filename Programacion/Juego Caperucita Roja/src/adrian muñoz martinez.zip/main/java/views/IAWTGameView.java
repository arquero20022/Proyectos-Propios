
package views;

import java.awt.Graphics;

public interface IAWTGameView {
    
  
    public void draw(Graphics g);
}
