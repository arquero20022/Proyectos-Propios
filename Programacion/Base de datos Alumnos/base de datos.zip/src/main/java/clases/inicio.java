
package clases;


public class inicio {
    public static void main(String[] args) {
  EstudianteControlador controlador = new EstudianteControlador();
  EstudianteVista vista = new EstudianteVista(controlador);
}
    
}
